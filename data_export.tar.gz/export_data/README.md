# BTC_Project
Repository for https://replit.com/@hxl1992hao/BitcoinMiningCalculator
