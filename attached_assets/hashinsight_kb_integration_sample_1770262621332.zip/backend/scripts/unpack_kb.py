#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
unpack_kb.py

Unpack a KB zip into a local directory cache.

Usage:
  python scripts/unpack_kb.py --kb_zip ../kb/miner_kb.zip --out_dir ../kb/unpacked

Notes:
  - The service can also unpack automatically; this script is for CI/build steps.
"""
import argparse, zipfile
from pathlib import Path

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--kb_zip", required=True)
    ap.add_argument("--out_dir", required=True)
    args = ap.parse_args()

    kb_zip = Path(args.kb_zip)
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(kb_zip, "r") as z:
        z.extractall(out_dir)

    print(f"Unpacked {kb_zip} -> {out_dir}")

if __name__ == "__main__":
    main()
