# UI integration notes (Event monitor + Ticket)

## Event Monitor
- When a miner event is raised (e.g., temperature high / hashrate drop / offline):
  - call POST /kb/diagnose with:
    - miner_id, model_id, brand
    - logs (last N lines)
    - metrics (snapshot)
  - display:
    - category, severity, confidence
    - selected.title
    - top 1-3 reasons (keyword/regex/metric)

## Ticket page
- “Create ticket” button:
  - call POST /kb/ticket-draft with same payload
  - pre-fill:
    - title
    - SOP steps (ticket.playbook.steps)
    - safety notes
    - artifacts checklist
    - verification checklist
- On close:
  - collect operator feedback (correct/incorrect + final fix) to feed ops_feedback table (future).
