# -*- coding: utf-8 -*-
"""
main.py (sample)

Integrate kb_routes into your existing FastAPI app.

If you already have an app factory, just include:
    app.include_router(kb_routes.router)
"""
from fastapi import FastAPI
from app.api import kb_routes

app = FastAPI(title="HashInsight Remote API")
app.include_router(kb_routes.router)
