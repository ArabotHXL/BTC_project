# -*- coding: utf-8 -*-
"""
kb_routes.py

FastAPI routes:
- GET /kb/version
- POST /kb/diagnose
- POST /kb/ticket-draft
- GET /kb/error-explain?brand=...&code=...
"""
from __future__ import annotations

from pathlib import Path
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from typing import Any, Dict, List, Optional

from app.services.miner_kb_service import MinerKnowledgeBaseService

router = APIRouter(prefix="/kb", tags=["kb"])

# ---- init singleton ----
# You can wire this into your existing dependency injection, or load at startup.
_KB_ZIP = Path(__file__).resolve().parents[3] / "kb" / "miner_kb.zip"
_CACHE = Path(__file__).resolve().parents[3] / "kb" / "cache"
kb = MinerKnowledgeBaseService.from_zip(_KB_ZIP, _CACHE)

class DiagnoseRequest(BaseModel):
    miner_id: str = Field(..., examples=["MINER-0001"])
    model_id: str = Field(default="generic_asic_miner")
    brand: str = Field(default="Unknown")
    timestamp: str = Field(default="")
    logs: List[str] = Field(default_factory=list)
    metrics: Dict[str, Any] = Field(default_factory=dict)

@router.get("/version")
def kb_version():
    return {
        "kb_version": kb.schema.get("version"),
        "description": kb.schema.get("description"),
        "signatures": len(kb.signatures),
        "playbooks": len(kb.playbooks),
        "brands_with_error_dict": list(kb.error_code_map.keys()),
    }

@router.post("/diagnose")
def kb_diagnose(req: DiagnoseRequest):
    diag = kb.diagnose(req.dict())
    # dataclass -> dict
    return {
        "miner_id": diag.miner_id,
        "model_id": diag.model_id,
        "brand": diag.brand,
        "timestamp": diag.timestamp,
        "confidence": diag.confidence,
        "selected": diag.selected.__dict__ if diag.selected else None,
        "top_hits": [h.__dict__ for h in diag.top_hits],
        "playbook": diag.playbook,
        "prevention": diag.prevention,
        "tuning": diag.tuning,
        "error_code_explanations": diag.error_code_explanations,
        "notes": diag.notes,
    }

@router.get("/error-explain")
def kb_error_explain(brand: str, code: str):
    e = kb.explain_error_code(brand, code)
    if not e:
        raise HTTPException(status_code=404, detail="Unknown code")
    return {"brand": brand, "code": code, "explanation": e}

@router.post("/ticket-draft")
def kb_ticket_draft(req: DiagnoseRequest):
    diag = kb.diagnose(req.dict())
    return kb.build_ticket_draft(diag)
