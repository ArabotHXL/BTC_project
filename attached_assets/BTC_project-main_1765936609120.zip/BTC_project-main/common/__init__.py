"""
Common utilities and shared components
通用工具和共享组件
"""

__version__ = '1.0.0'
