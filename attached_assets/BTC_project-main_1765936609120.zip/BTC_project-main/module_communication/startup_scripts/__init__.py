"""
Startup Scripts for Module Communication
模块通信启动脚本包
"""