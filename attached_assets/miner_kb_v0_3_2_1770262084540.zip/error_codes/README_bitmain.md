Bitmain codes are primarily log-string prompts.
Use bitmain_antminer_log_codes_v1.json.
