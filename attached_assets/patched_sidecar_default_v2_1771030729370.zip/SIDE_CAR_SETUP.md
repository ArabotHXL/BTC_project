# Sidecar setup (default)

This project is patched to support a same-domain "sidecar" auxiliary UI embedded in `analytics_main.html`.

## How to build situation-monitor (recommended)
Build output is static and can be served from Flask.

- Build command: `npm run build`
- SvelteKit adapter-static outputs to `build/` and uses `app.html` as fallback.
- The project supports a configurable base path via `BASE_PATH`.

Example:

```bash
git clone https://github.com/hipcityreg/situation-monitor
cd situation-monitor
npm ci
BASE_PATH=/analytics/sidecar npm run build
# copy build output into your Flask app:
#   <your_flask_app>/static/sidecar/
# so that static/sidecar/app.html exists
cp -r build/* /path/to/your_flask_app/static/sidecar/
```

## Security headers checklist
- `X-Frame-Options: SAMEORIGIN`
- If you enable CSP, allow same-domain frames:
  - `frame-src 'self'`
  - optionally: `frame-ancestors 'self'`
