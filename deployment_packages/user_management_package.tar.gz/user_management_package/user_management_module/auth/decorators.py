"""
权限控制装饰器
提供细粒度的功能访问控制
"""

from functools import wraps
from flask import session, redirect, url_for, render_template, flash
import logging

def requires_role(required_roles):
    """
    角色权限装饰器
    参数：required_roles - 允许访问的角色列表（字符串或列表）
    """
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            # 检查用户是否已登录
            if not session.get('authenticated'):
                flash('请先登录以访问此功能', 'warning')
                return redirect(url_for('auth.login'))
            
            # 标准化角色列表
            if isinstance(required_roles, str):
                roles = [required_roles]
            else:
                roles = required_roles
            
            # 获取当前用户角色
            current_role = session.get('role', 'guest')
            
            # Owner拥有所有权限
            if current_role == 'owner':
                return func(*args, **kwargs)
            
            # 检查角色权限
            if current_role in roles:
                return func(*args, **kwargs)
            
            # 权限不足
            logging.warning(f"用户 {session.get('email')} (角色: {current_role}) 尝试访问需要 {roles} 权限的功能")
            return render_template('errors/unauthorized.html', 
                                 message=f'此功能需要以下角色权限: {", ".join(roles)}',
                                 required_roles=roles,
                                 current_role=current_role), 403
        
        return wrapper
    return decorator

def requires_owner_only(func):
    """仅限拥有者访问的装饰器"""
    @wraps(func)
    def wrapper(*args, **kwargs):
        if not session.get('authenticated'):
            flash('请先登录以访问此功能', 'warning')
            return redirect(url_for('auth.login'))
        
        current_role = session.get('role', 'guest')
        if current_role != 'owner':
            logging.warning(f"用户 {session.get('email')} (角色: {current_role}) 尝试访问拥有者专属功能")
            return render_template('errors/unauthorized.html', 
                                 message='此功能仅限系统拥有者访问',
                                 required_roles=['owner'],
                                 current_role=current_role), 403
        
        return func(*args, **kwargs)
    return wrapper

def requires_admin_or_owner(func):
    """需要管理员或拥有者权限的装饰器"""
    @wraps(func)
    def wrapper(*args, **kwargs):
        if not session.get('authenticated'):
            flash('请先登录以访问此功能', 'warning')
            return redirect(url_for('auth.login'))
        
        current_role = session.get('role', 'guest')
        if current_role not in ['owner', 'admin']:
            logging.warning(f"用户 {session.get('email')} (角色: {current_role}) 尝试访问管理员功能")
            return render_template('errors/unauthorized.html', 
                                 message='此功能需要管理员或拥有者权限',
                                 required_roles=['owner', 'admin'],
                                 current_role=current_role), 403
        
        return func(*args, **kwargs)
    return wrapper

def requires_crm_access(func):
    """需要CRM访问权限的装饰器 - 仅限拥有者和管理员"""
    @wraps(func)
    def wrapper(*args, **kwargs):
        if not session.get('authenticated'):
            flash('请先登录以访问此功能', 'warning')
            return redirect(url_for('auth.login'))
        
        current_role = session.get('role', 'guest')
        if current_role not in ['owner', 'admin']:
            logging.warning(f"用户 {session.get('email')} (角色: {current_role}) 尝试访问CRM功能")
            return render_template('errors/unauthorized.html', 
                                 message='CRM系统仅限拥有者和管理员使用',
                                 required_roles=['owner', 'admin'],
                                 current_role=current_role), 403
        
        return func(*args, **kwargs)
    return wrapper

def requires_billing_access(func):
    """需要计费访问权限的装饰器"""
    @wraps(func)
    def wrapper(*args, **kwargs):
        if not session.get('authenticated'):
            flash('请先登录以访问此功能', 'warning')
            return redirect(url_for('auth.login'))
        
        current_role = session.get('role', 'guest')
        if current_role not in ['owner', 'admin']:
            logging.warning(f"用户 {session.get('email')} (角色: {current_role}) 尝试访问计费功能")
            return render_template('errors/unauthorized.html', 
                                 message='计费管理功能仅限拥有者和管理员使用',
                                 required_roles=['owner', 'admin'],
                                 current_role=current_role), 403
        
        return func(*args, **kwargs)
    return wrapper

# 数据访问权限装饰器
def requires_own_data_only(user_id_param='user_id'):
    """
    仅访问自己数据的装饰器
    适用于用户只能查看自己创建的数据
    """
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            if not session.get('authenticated'):
                flash('请先登录以访问此功能', 'warning')
                return redirect(url_for('auth.login'))
            
            current_role = session.get('role', 'guest')
            current_user_id = session.get('user_id')
            
            # Owner和Admin可以访问所有数据
            if current_role in ['owner', 'admin']:
                return func(*args, **kwargs)
            
            # 检查请求的数据是否属于当前用户
            requested_user_id = kwargs.get(user_id_param)
            if requested_user_id and str(requested_user_id) != str(current_user_id):
                logging.warning(f"用户 {session.get('email')} 尝试访问其他用户的数据")
                return render_template('errors/unauthorized.html', 
                                     message='您只能访问自己创建的数据',
                                     current_role=current_role), 403
            
            return func(*args, **kwargs)
        
        return wrapper
    return decorator

def log_access_attempt(feature_name):
    """记录功能访问尝试的装饰器"""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            user_email = session.get('email', '匿名用户')
            user_role = session.get('role', '未知角色')
            
            logging.info(f"功能访问: {feature_name} - 用户: {user_email} (角色: {user_role})")
            
            return func(*args, **kwargs)
        
        return wrapper
    return decorator

# 订阅计划相关功能实现
def get_user_plan(user_id=None):
    """获取用户订阅计划"""
    if not user_id:
        user_id = session.get('user_id')
    
    if not user_id:
        return get_default_free_plan()
    
    try:
        from ..models import UserSubscription, SubscriptionPlan
        
        # 查找用户当前的有效订阅
        subscription = UserSubscription.query.filter_by(
            user_id=user_id,
            status='active'
        ).first()
        
        if subscription and subscription.is_active():
            return subscription.plan
        
        # 特殊处理：如果是测试账户，直接基于邮箱给予相应权限
        user_email = session.get('email', '').lower()
        if user_email == 'test_pro@test.com':
            return SubscriptionPlan.query.filter_by(plan_type='professional').first()
        elif user_email == 'test_basic@test.com':
            return SubscriptionPlan.query.filter_by(plan_type='basic').first()
        elif user_email == 'test_free@test.com':
            return SubscriptionPlan.query.filter_by(plan_type='free').first()
        else:
            return get_default_free_plan()
            
    except Exception as e:
        logging.error(f"获取用户计划失败: {e}")
        return get_default_free_plan()

def get_default_free_plan():
    """获取默认免费计划"""
    try:
        from ..models import SubscriptionPlan
        plan = SubscriptionPlan.query.filter_by(plan_type='free').first()
        if plan:
            return plan
    except:
        pass
    
    # 创建临时免费计划对象
    class FreePlan:
        id = 'free'
        name = 'Free'
        plan_type = 'free'
        max_users = 5
        max_api_calls_per_day = 100
        has_advanced_analytics = False
        has_export_features = False
        has_priority_support = False
        has_custom_alerts = False
        has_api_access = False
    
    return FreePlan()

def get_user_subscription(user_id=None):
    """获取用户订阅信息"""
    if not user_id:
        user_id = session.get('user_id')
    
    try:
        from ..models import UserSubscription
        subscription = UserSubscription.query.filter_by(
            user_id=user_id,
            status='active'
        ).first()
        
        if subscription:
            return {
                'plan': subscription.plan.plan_type,
                'status': subscription.status,
                'expires_at': subscription.expires_at
            }
        else:
            return {'plan': 'free', 'status': 'active', 'expires_at': None}
    except Exception as e:
        logging.error(f"获取用户订阅信息失败: {e}")
        return {'plan': 'free', 'status': 'active', 'expires_at': None}

def check_feature_access(feature_name, user_id=None):
    """检查用户功能访问权限"""
    try:
        # Owner账户不受订阅计划限制
        current_role = session.get('role', 'guest')
        if current_role == 'owner':
            return True
        
        user_plan = get_user_plan(user_id)
        
        # 功能权限映射
        feature_map = {
            'crm_system': 'has_crm_access',
            'advanced_analytics': 'has_advanced_analytics',
            'api_access': 'has_api_access',
            'export_features': 'has_export_features',
            'priority_support': 'has_priority_support',
            'custom_alerts': 'has_custom_alerts'
        }
        
        required_attr = feature_map.get(feature_name)
        if required_attr:
            return getattr(user_plan, required_attr, False)
        
        return True  # 默认允许访问
        
    except Exception as e:
        logging.error(f"检查功能访问权限时出错: {e}")
        return False

class UpgradeRequired(Exception):
    """需要升级订阅的异常"""
    def __init__(self, feature_name, required_plan=None):
        self.feature_name = feature_name
        self.required_plan = required_plan
        super().__init__(f"Feature '{feature_name}' requires {required_plan or 'upgrade'}")

def require_plan(plan_name):
    """需要特定计划的装饰器 - Owner账户不受限制"""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            # Owner账户不受订阅计划限制
            current_role = session.get('role', 'guest')
            if current_role == 'owner':
                return func(*args, **kwargs)
            
            user_plan = get_user_plan()
            current_plan = getattr(user_plan, 'plan_type', 'free')
            
            plan_hierarchy = {'free': 0, 'basic': 1, 'professional': 2, 'enterprise': 3}
            
            required_level = plan_hierarchy.get(plan_name, 2)
            current_level = plan_hierarchy.get(current_plan, 0)
            
            if current_level < required_level:
                from flask import render_template
                return render_template('errors/upgrade_required.html',
                                     feature=func.__name__,
                                     required_plan=plan_name,
                                     current_plan=current_plan), 402
            
            return func(*args, **kwargs)
        return wrapper
    return decorator

def require_feature(feature_name):
    """需要特定功能的装饰器 - Owner账户不受限制"""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            # Owner账户不受订阅功能限制
            current_role = session.get('role', 'guest')
            if current_role == 'owner':
                return func(*args, **kwargs)
            
            if not check_feature_access(feature_name):
                from flask import render_template
                user_plan = get_user_plan()
                return render_template('errors/upgrade_required.html',
                                     feature=feature_name,
                                     current_plan=getattr(user_plan, 'plan_type', 'free')), 402
            
            return func(*args, **kwargs)
        return wrapper
    return decorator

def requires_subscription_plan(required_plan):
    """需要特定订阅计划的装饰器"""
    return require_plan(required_plan)