# Bitcoin Mining Calculator - Advanced Analytics Platform

## 高级分析平台功能

这是Bitcoin Mining Calculator的高级分析包，包含以下功能：
- HashInsight Treasury Management Platform
- CRM客户关系管理系统
- 高级算法交易信号
- Deribit期权分析
- 托管业务管理
- 专业报告生成

## 安装和运行

1. 安装依赖：
```bash
pip install -r requirements.txt
```

2. 设置环境变量：
```bash
export DATABASE_URL="your_database_url"
export SESSION_SECRET="your_secret_key"
export DERIBIT_API_KEY="your_deribit_key"
export STRIPE_SECRET_KEY="your_stripe_key"
```

3. 运行应用：
```bash
python main.py
```

## 功能特点

- 📊 HashInsight Treasury Management
- 🏢 CRM客户关系管理
- 🤖 高级算法交易信号
- 💼 期权交易分析
- 🏭 托管业务管理
- 📈 专业报告生成
- 🔄 多交易所数据集成
- 💰 佣金管理系统

## 依赖核心包

此高级包需要与核心包配合使用。请确保已安装核心包的所有依赖。
