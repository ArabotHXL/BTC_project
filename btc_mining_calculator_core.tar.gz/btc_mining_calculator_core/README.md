# Bitcoin Mining Calculator - Core Package

## 核心挖矿计算器功能

这是Bitcoin Mining Calculator的核心包，包含以下功能：
- 挖矿收益计算器
- 用户认证系统  
- 基础数据管理
- 多语言支持
- 订阅管理

## 安装和运行

1. 安装依赖：
```bash
pip install -r requirements.txt
```

2. 设置环境变量：
```bash
export DATABASE_URL="your_database_url"
export SESSION_SECRET="your_secret_key"
```

3. 运行应用：
```bash
python main.py
```

或使用Gunicorn：
```bash
gunicorn --bind 0.0.0.0:5000 main:app
```

## 功能特点

- ⛏️ 挖矿收益计算器
- 👥 用户认证和管理
- 💰 订阅计划管理
- 🌐 中英文双语支持
- 📊 基础数据分析
